# API Documentation - Travelogic ChatGPT Endpoint

## Overview

The Travelogic backend now includes a ChatGPT integration endpoint that allows the chatbot frontend to get AI-powered responses for user queries.

---

## Endpoint Details

### POST `/api/chat`

Sends a user message to ChatGPT and returns an AI-generated response.

#### URL
```
POST http://localhost:3000/api/chat
```

#### Headers
```json
{
  "Content-Type": "application/json"
}
```

#### Request Body
```json
{
  "message": "Plan a trip to Thailand"
}
```

#### Response (Success)
```json
{
  "reply": "Great choice! Thailand is amazing for travelers. Here's a basic plan..."
}
```

#### Response (Error)
```json
{
  "error": "OpenAI API key not configured. Please set OPENAI_API_KEY environment variable."
}
```

---

## Implementation Details

### Technology Stack
- **Backend**: Node.js + Express.js
- **AI Model**: OpenAI GPT-3.5-turbo
- **API Library**: openai npm package

### Configuration
```javascript
// server.js
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});
```

### Chat Parameters
| Parameter | Value | Description |
|-----------|-------|-------------|
| model | gpt-3.5-turbo | OpenAI model to use |
| max_tokens | 500 | Maximum response length |
| temperature | 0.7 | Creativity level (0-1) |
| system prompt | Travel assistant | Guides bot behavior |

---

## Request Examples

### cURL
```bash
curl -X POST http://localhost:3000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Best hotels in Sylhet"}'
```

### JavaScript/Fetch
```javascript
fetch('/api/chat', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    message: 'Best hotels in Sylhet'
  })
})
.then(response => response.json())
.then(data => console.log(data.reply))
.catch(error => console.error('Error:', error));
```

### Python
```python
import requests

url = 'http://localhost:3000/api/chat'
data = {'message': 'Best hotels in Sylhet'}
response = requests.post(url, json=data)
print(response.json()['reply'])
```

### JavaScript/Axios
```javascript
const axios = require('axios');

axios.post('http://localhost:3000/api/chat', {
  message: 'Best hotels in Sylhet'
})
.then(response => console.log(response.data.reply))
.catch(error => console.error(error));
```

---

## Error Handling

### 400 Bad Request
```json
{
  "error": "Message is required"
}
```
**When:** No message provided or message is empty

---

### 500 API Key Not Configured
```json
{
  "error": "OpenAI API key not configured. Please set OPENAI_API_KEY environment variable."
}
```
**When:** OPENAI_API_KEY environment variable is not set

---

### 500 Invalid API Key
```json
{
  "error": "Invalid OpenAI API key. Please check your OPENAI_API_KEY."
}
```
**When:** API key is invalid or revoked

---

### 429 Rate Limit Exceeded
```json
{
  "error": "OpenAI rate limit exceeded. Please try again later."
}
```
**When:** Too many requests or quota exceeded

---

### 500 Server Error
```json
{
  "error": "Failed to get response from ChatGPT. Please try again."
}
```
**When:** Other server-side errors occur

---

## System Prompt

The bot uses this system prompt to guide responses:

```
You are Travelogic Assistant, a helpful AI travel planning chatbot. 
You assist users with:
- Travel planning and itineraries
- Flight bookings and recommendations
- Hotel and accommodation suggestions
- Budget planning and cost estimates
- Local attractions and tourist information
- Travel tips and destination guides

You are conversational, friendly, and helpful. Keep responses concise but informative. 
Use emojis occasionally to make responses engaging. When users ask about Travelogic, 
explain that it's an AI-powered travel planning platform.
```

---

## Performance Metrics

### Response Time
- Average: 2-3 seconds
- Range: 1-5 seconds (depending on OpenAI load)

### Token Usage
- Average per message: 50-100 tokens input, 100-200 tokens output
- Cost: ~$0.0002 per message on gpt-3.5-turbo

### Max Request Size
- Message length: No hard limit, but keep under 2000 characters for best performance

---

## Best Practices

### 1. Error Handling
Always handle errors gracefully:
```javascript
try {
  const response = await fetch('/api/chat', {...});
  if (!response.ok) {
    const error = await response.json();
    console.error('API Error:', error.error);
  }
} catch (error) {
  console.error('Network Error:', error);
}
```

### 2. Loading States
Show loading indicator while waiting for response:
```javascript
sendButton.disabled = true;
showTypingIndicator();

fetch('/api/chat', {...})
  .then(...)
  .finally(() => {
    sendButton.disabled = false;
    removeTypingIndicator();
  });
```

### 3. Rate Limiting
Implement client-side rate limiting to prevent abuse:
```javascript
let lastRequestTime = 0;
const MIN_INTERVAL = 1000; // 1 second between requests

function canSendMessage() {
  const now = Date.now();
  if (now - lastRequestTime < MIN_INTERVAL) {
    return false;
  }
  lastRequestTime = now;
  return true;
}
```

### 4. Message Validation
Validate messages before sending:
```javascript
if (!message || message.trim().length === 0) {
  alert('Please enter a message');
  return;
}
if (message.length > 2000) {
  alert('Message is too long');
  return;
}
```

---

## Integration Checklist

- ✅ OpenAI npm package installed
- ✅ OPENAI_API_KEY environment variable set
- ✅ Server running on port 3000
- ✅ Endpoint is `/api/chat`
- ✅ Request method is POST
- ✅ Content-Type is application/json
- ✅ Response format is `{reply: "..."}` or `{error: "..."}`

---

## Troubleshooting

### API Endpoint Not Found
**Error:** 404 Not Found
**Solution:** Make sure your server.js has the chat endpoint added

### CORS Error
**Error:** "Access to XMLHttpRequest blocked by CORS policy"
**Solution:** Make sure you're accessing via http://localhost:3000

### Timeout
**Error:** "Request timeout"
**Solution:** OpenAI might be slow, increase timeout or check status.openai.com

### Empty Response
**Error:** Message sent but no response
**Solution:** Check OpenAI API status and your API key validity

---

## Future Enhancements

- [ ] Add conversation history/context
- [ ] Implement streaming responses
- [ ] Add image generation endpoint
- [ ] Support for different AI models
- [ ] Rate limiting middleware
- [ ] Request logging and analytics
- [ ] Cache common responses
- [ ] Add webhooks for async responses

---

## Related Files

- `server.js` - Backend implementation
- `chatbot.html` - Frontend implementation
- `package.json` - Dependencies

---

## Additional Resources

- [OpenAI API Documentation](https://platform.openai.com/docs/api-reference)
- [OpenAI Chat Completions](https://platform.openai.com/docs/guides/gpt)
- [openai npm Package](https://github.com/openai/node-sdk)
- [Express.js Middleware](https://expressjs.com/en/guide/using-middleware.html)

---

## Support

For issues with:
- **API Integration:** Check server.js implementation
- **Frontend:** Check chatbot.html and browser console
- **OpenAI API:** Visit https://platform.openai.com/docs
- **Environment Setup:** See CHATGPT_SETUP.md

Version: 1.0
Last Updated: 2024
