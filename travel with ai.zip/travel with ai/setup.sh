#!/bin/bash
# Run this script on Mac/Linux to set up and start the chatbot
# Usage: chmod +x setup.sh && ./setup.sh

# Get API key from user
echo "🚀 Travelogic ChatGPT Setup"
echo "============================"
echo ""
echo "1. Get your API key from: https://platform.openai.com/api-keys"
echo ""

read -p "Enter your OpenAI API key: " API_KEY

if [ -z "$API_KEY" ]; then
    echo "❌ API key is required!"
    exit 1
fi

# Create .env file
cat > .env << EOF
OPENAI_API_KEY=$API_KEY
PORT=3000
JWT_SECRET=change_this_secret
EOF

echo "✅ .env file created"
echo ""
echo "Installing dependencies..."
npm install

echo ""
echo "✅ Setup complete!"
echo ""
echo "Starting server..."
npm start
