# ChatGPT Integration Setup Guide

## What's Been Added

Your Travelogic project now includes **ChatGPT integration**! The chatbot is now powered by real AI instead of hardcoded responses.

## Files Modified/Created:

1. **chatbot.html** - New WhatsApp-style chatbot UI with ChatGPT integration
2. **server.js** - Updated with `/api/chat` endpoint for ChatGPT communication
3. **package.json** - Added OpenAI dependency

## Setup Instructions

### Step 1: Install Dependencies

Run this command in your project directory:

```bash
npm install
```

This will install the OpenAI package needed for ChatGPT integration.

### Step 2: Get Your OpenAI API Key

1. Go to [OpenAI Platform](https://platform.openai.com/api-keys)
2. Sign up or log in to your account
3. Click "Create new secret key"
4. Copy your API key (keep it safe!)

### Step 3: Set Environment Variable

**Windows (Command Prompt):**
```cmd
set OPENAI_API_KEY=your_api_key_here
```

**Windows (PowerShell):**
```powershell
$env:OPENAI_API_KEY="your_api_key_here"
```

**Mac/Linux:**
```bash
export OPENAI_API_KEY=your_api_key_here
```

Replace `your_api_key_here` with your actual API key from step 2.

### Step 4: Start Your Server

```bash
npm start
```

Your server will run on `http://localhost:3000`

### Step 5: Access the Chatbot

Open your browser and go to:
```
http://localhost:3000/chatbot.html
```

## Features

✨ **Real ChatGPT Responses** - Powered by OpenAI's GPT-3.5-turbo
💬 **Smart Context** - Bot understands travel-related queries
⚡ **Fast Responses** - Optimized API calls
🎯 **Travel-Focused** - Specialized system prompt for travel assistance
🔒 **Error Handling** - Clear messages if configuration is missing

## Customization

### Change the Bot Personality

Edit the system prompt in `server.js` (line ~48) to customize the bot's behavior:

```javascript
content: `You are Travelogic Assistant, a helpful AI travel planning chatbot...`
```

### Adjust Response Parameters

In `server.js`, you can modify:
- `max_tokens`: 500 (maximum response length)
- `temperature`: 0.7 (creativity level, 0-1)
- `model`: 'gpt-3.5-turbo' (can use 'gpt-4' if you have access)

## Troubleshooting

### "API key not configured"
- Make sure you've set the `OPENAI_API_KEY` environment variable
- Restart your server after setting it

### "Invalid API key"
- Double-check your API key from OpenAI dashboard
- Ensure you haven't shared it with anyone

### "Rate limit exceeded"
- You might be making too many requests
- Wait a few minutes and try again
- Check your OpenAI usage on their dashboard

### Messages not sending
- Check browser console for errors (F12)
- Verify server is running on port 3000
- Check network tab to see API responses

## Testing

Try these prompts to test:
- "Plan a trip to Thailand for 5 days"
- "What are the best hotels in Sylhet?"
- "How much should I budget for a trip to Bangladesh?"
- "Tell me about local attractions in Sylhet"

## API Usage & Costs

- OpenAI charges based on tokens used
- Free trial includes some credits
- Monitor your usage at [OpenAI Usage Dashboard](https://platform.openai.com/account/usage/overview)

## File Structure

```
travel-with-ai/
├── index.html          (Main landing page)
├── chatbot.html        (NEW - ChatGPT chatbot)
├── server.js           (UPDATED - with /api/chat endpoint)
├── package.json        (UPDATED - with openai dependency)
├── signin.html
├── signup.html
├── assets/
├── data/
└── node_modules/
```

## Next Steps

1. ✅ Install dependencies: `npm install`
2. ✅ Set OPENAI_API_KEY environment variable
3. ✅ Start server: `npm start`
4. ✅ Open: http://localhost:3000/chatbot.html
5. ✅ Start chatting!

## Support

If you need help:
1. Check the troubleshooting section above
2. Review the API endpoint in `server.js`
3. Check OpenAI API documentation
4. Verify your API key has access to the gpt-3.5-turbo model

Enjoy your AI-powered travel chatbot! 🚀✈️
