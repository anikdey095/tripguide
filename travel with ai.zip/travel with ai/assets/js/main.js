document.addEventListener('DOMContentLoaded', () => {
  const guideBtn = document.getElementById('guideBtn')
  const signinBtn = document.getElementById('signinBtn')
  const bannerSign = document.getElementById('bannerSign')
  const banner = document.querySelector('.floating-banner')
  const guideInput = document.getElementById('search')

  function getToken(){ return localStorage.getItem('travelogic_token') }
  function getCurrentUser(){ try{ const raw = localStorage.getItem('travelogic_user'); return raw? JSON.parse(raw): null }catch(e){return null} }
  function setUserAndToken(user, token){ localStorage.setItem('travelogic_user', JSON.stringify(user)); localStorage.setItem('travelogic_token', token) }
  function signOut(){ localStorage.removeItem('travelogic_user'); localStorage.removeItem('travelogic_token'); location.reload() }

  // Guide button
  if(guideBtn){
    guideBtn.addEventListener('click', ()=>{
      const q = (guideInput && guideInput.value.trim()) || 'Sylhet highlights'
      alert('AI Guide is preparing suggestions for: ' + q)
    })
  }

  // Banner toggle (if any)
  function toggleBanner(){ if(!banner) return; banner.style.display = banner.style.display === 'none' ? 'flex' : 'none' }

  // Sign-in button behavior using token
  const currentUser = getCurrentUser()
  if(signinBtn){
    if(getToken() && currentUser){
      signinBtn.textContent = `Hi, ${currentUser.name}`
      signinBtn.addEventListener('click', ()=>{ if(confirm('Sign out from Travelogic?')) signOut() })
    } else {
      signinBtn.addEventListener('click', ()=>{ window.location.href = 'signin.html' })
    }
  }
  if(bannerSign) bannerSign.addEventListener('click', ()=>{ window.location.href = 'signin.html' })

  // Plan form
  const planForm = document.getElementById('planForm')
  if(planForm) planForm.addEventListener('submit', e=>{
    e.preventDefault()
    const days = document.getElementById('duration').value
    const budget = document.getElementById('budget').value
    const pref = document.getElementById('pref').value
    alert(`Trip plan saved — ${days} days, BDT ${budget}, pref ${pref}`)
  })

  // Stories carousel
  const stories = document.getElementById('stories')
  if(stories){
    let idx = 0; const items = stories.children
    setInterval(()=>{ idx = (idx+1) % items.length; for(let i=0;i<items.length;i++) items[i].style.opacity = i===idx? '1':'0.45' },3500)
  }

  // Populate destinations from API
  const destContainer = document.querySelector('.destinations')
  if(destContainer){
    fetch('/api/destinations')
      .then(r=>r.json())
      .then(list=>{
        destContainer.innerHTML = ''
        list.forEach(d=>{
          const card = document.createElement('div'); card.className = 'card'
          card.innerHTML = `
            <div class="thumb">
              <img src="${d.image || 'assets/images/card1.svg'}" alt="${d.title}" />
              <div class="thumb-label">${d.title}</div>
            </div>
            <div class="card-info"><h3>${d.title}</h3><p class="muted">${d.short || ''}</p></div>
          `
          destContainer.appendChild(card)
        })
      }).catch(()=>{/* ignore */})
  }

  // Populate hotels from API
  const hotelsGrid = document.querySelector('.hotels-grid')
  if(hotelsGrid){
    fetch('/api/hotels')
      .then(r=>r.json())
      .then(list=>{
        hotelsGrid.innerHTML = ''
        list.forEach(h=>{
          const img = h.image && h.image.startsWith('/')? h.image : (h.image || `https://source.unsplash.com/400x260/?hotel`)
          const card = document.createElement('div'); card.className = 'hotel-card'
          card.innerHTML = `
            <img src="${img}" alt="${h.name}">
            <div class="hotel-body">
              <h4>${h.name}</h4>
              <div class="meta">${h.rating} ★ &nbsp; · &nbsp; From BDT ${h.price}/night</div>
              <button class="btn" data-hotel="${h.name}">Book</button>
            </div>
          `
          hotelsGrid.appendChild(card)
        })

        // attach handlers
        document.querySelectorAll('.hotel-card .btn').forEach(btn=>{
          btn.addEventListener('click', ()=>{
            const hotel = btn.getAttribute('data-hotel') || 'Selected hotel'
            if(!getToken()){ if(confirm('Sign in required to book. Go to sign-in?')) window.location.href='signin.html'; return }
            alert(`Booking placeholder — ${hotel}.`)
          })
        })
      }).catch(()=>{/* ignore */})
  }
})
