const express = require('express');
const path = require('path');
const fs = require('fs');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const bodyParser = require('body-parser');
const { OpenAI } = require('openai');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'change_this_secret';
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';

// Initialize OpenAI
const openai = new OpenAI({
  apiKey: OPENAI_API_KEY
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Serve static frontend files from project root
app.use(express.static(path.join(__dirname)));

// Ensure data directory exists
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const dbFile = path.join(dataDir, 'db.sqlite');
const db = new sqlite3.Database(dbFile);

// Initialize DB and seed sample data
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT UNIQUE,
    password TEXT
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS hotels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    city TEXT,
    image TEXT,
    rating REAL,
    price INTEGER
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS destinations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    short TEXT,
    image TEXT
  )`);

  // Seed hotels if empty
  db.get('SELECT COUNT(*) as c FROM hotels', (err, row) => {
    if (!err && row && row.c === 0) {
      const stmt = db.prepare('INSERT INTO hotels (name,city,image,rating,price) VALUES (?,?,?,?,?)');
      stmt.run('Sylhet Grand Hotel','Sylhet','/assets/images/card1.svg',4.3,45);
      stmt.run('Jaflong Riverside Resort','Jaflong','/assets/images/card2.svg',4.6,60);
      stmt.run('Tea Valley Inn','Sylhet','/assets/images/card3.svg',4.1,35);
      stmt.finalize();
    }
  });

  // Seed destinations if empty
  db.get('SELECT COUNT(*) as c FROM destinations', (err, row) => {
    if (!err && row && row.c === 0) {
      const stmt = db.prepare('INSERT INTO destinations (title,short,image) VALUES (?,?,?)');
      stmt.run('Jaflong','Riverside tea gardens and stone collection','/assets/images/jaflong.jpg');
      stmt.run('Ratargul','Freshwater swamp forest','/assets/images/card2.svg');
      stmt.run('Lalakhal','Crystal clear boat rides','/assets/images/card3.svg');
      stmt.finalize();
    }
  });
});

// Simple helper to protect routes
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
}

// Auth: register
app.post('/api/auth/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
  try {
    const hashed = await bcrypt.hash(password, 10);
    const stmt = db.prepare('INSERT INTO users (name,email,password) VALUES (?,?,?)');
    stmt.run(name || '', email, hashed, function (err) {
      if (err) return res.status(400).json({ error: 'User already exists or invalid' });
      const user = { id: this.lastID, name, email };
      const token = jwt.sign(user, JWT_SECRET, { expiresIn: '7d' });
      res.json({ user, token });
    });
  } catch (e) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Auth: login
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
  db.get('SELECT * FROM users WHERE email = ?', [email], async (err, row) => {
    if (err) return res.status(500).json({ error: 'Server error' });
    if (!row) return res.status(400).json({ error: 'Invalid credentials' });
    const match = await bcrypt.compare(password, row.password);
    if (!match) return res.status(400).json({ error: 'Invalid credentials' });
    const user = { id: row.id, name: row.name, email: row.email };
    const token = jwt.sign(user, JWT_SECRET, { expiresIn: '7d' });
    res.json({ user, token });
  });
});

// Public APIs
app.get('/api/hotels', (req, res) => {
  db.all('SELECT id,name,city,image,rating,price FROM hotels', (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json(rows);
  });
});

app.get('/api/destinations', (req, res) => {
  db.all('SELECT id,title,short,image FROM destinations', (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });
    res.json(rows);
  });
});

// Example protected route
app.get('/api/me', authenticateToken, (req, res) => {
  res.json({ user: req.user });
});

// ChatGPT API endpoint for Travelogic chatbot
app.post('/api/chat', async (req, res) => {
  const { message } = req.body;
  
  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Message is required' });
  }
  
  if (!OPENAI_API_KEY) {
    return res.status(500).json({ error: 'OpenAI API key not configured. Please set OPENAI_API_KEY environment variable.' });
  }
  
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        {
          role: 'system',
          content: `You are Travelogic Assistant, a helpful AI travel planning chatbot. You assist users with:
- Travel planning and itineraries
- Flight bookings and recommendations
- Hotel and accommodation suggestions
- Budget planning and cost estimates
- Local attractions and tourist information
- Travel tips and destination guides

You are conversational, friendly, and helpful. Keep responses concise but informative. Use emojis occasionally to make responses engaging. When users ask about Travelogic, explain that it's an AI-powered travel planning platform.`
        },
        {
          role: 'user',
          content: message
        }
      ],
      max_tokens: 500,
      temperature: 0.7
    });
    
    const botReply = response.choices[0].message.content;
    res.json({ reply: botReply });
  } catch (error) {
    console.error('OpenAI API error:', error);
    
    if (error.status === 401) {
      return res.status(500).json({ error: 'Invalid OpenAI API key. Please check your OPENAI_API_KEY.' });
    } else if (error.status === 429) {
      return res.status(429).json({ error: 'OpenAI rate limit exceeded. Please try again later.' });
    }
    
    res.status(500).json({ error: 'Failed to get response from ChatGPT. Please try again.' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
