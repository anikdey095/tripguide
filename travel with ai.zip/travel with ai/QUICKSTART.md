# 🚀 Quick Start: ChatGPT Chatbot Integration

## ⚡ 3-Minute Setup

### 1️⃣ Install Dependencies
```bash
npm install
```

### 2️⃣ Get OpenAI API Key
- Visit: https://platform.openai.com/api-keys
- Click "Create new secret key"
- Copy your key

### 3️⃣ Set API Key (Choose One)

**Windows Command Prompt:**
```cmd
set OPENAI_API_KEY=sk-...your-key-here...
npm start
```

**Windows PowerShell:**
```powershell
$env:OPENAI_API_KEY="sk-...your-key-here..."
npm start
```

**Mac/Linux:**
```bash
export OPENAI_API_KEY=sk-...your-key-here...
npm start
```

### 4️⃣ Open Chatbot
```
http://localhost:3000/chatbot.html
```

---

## 📝 What Changed?

| File | Change |
|------|--------|
| `package.json` | ✅ Added `openai` package |
| `server.js` | ✅ Added `/api/chat` endpoint |
| `chatbot.html` | ✨ **NEW** - Real ChatGPT-powered chatbot |
| `CHATGPT_SETUP.md` | 📖 Detailed setup guide |
| `.env.example` | 📋 Environment variables template |

---

## 🧪 Test It

Type these in the chatbot:
- "Plan a 3-day trip to Thailand"
- "Best hotels in Sylhet under $50/night"
- "5-day trip itinerary for mountain lovers"
- "What's the best time to visit Bangladesh?"

---

## ⚠️ Troubleshooting

| Issue | Solution |
|-------|----------|
| "API key not configured" | Set OPENAI_API_KEY environment variable before starting server |
| "Invalid API key" | Check your key at https://platform.openai.com/api-keys |
| Chat not responding | Make sure server is running on port 3000 |
| Rate limit error | Wait a minute, try again (free tier has limits) |

---

## 🔧 Advanced Options

### Change Response Length
In `server.js`, line ~166:
```javascript
max_tokens: 500,  // Change this number (higher = longer responses)
```

### Change Bot Personality
In `server.js`, line ~157:
```javascript
content: `You are Travelogic Assistant...`  // Edit this prompt
```

### Use GPT-4 (if available)
In `server.js`, line ~164:
```javascript
model: 'gpt-4',  // Instead of 'gpt-3.5-turbo'
```

---

## 📊 Monitor Usage

Check your API usage anytime:
https://platform.openai.com/account/usage/overview

---

## 🎯 Next Steps

1. ✅ Install and run chatbot
2. 📝 Test with various travel questions
3. 🎨 Customize bot personality in server.js
4. 🚀 Deploy to production (use environment variables for API key)

---

## 💡 Pro Tips

- Keep API key secret, never share it
- Use environment variables in production
- Monitor API usage to avoid unexpected charges
- Set reasonable `max_tokens` to control costs
- The bot inherits travel knowledge from ChatGPT

Enjoy your AI travel assistant! ✈️🌍
