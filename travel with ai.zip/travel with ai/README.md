# Travelogic — AI-Powered Travel Assistant

A full-stack travel planning application with a WhatsApp-style ChatGPT-powered chatbot, Express backend, and SQLite database.

## ✨ New Feature: ChatGPT-Powered Chatbot

This project now includes a **real ChatGPT chatbot** for travel assistance! The chatbot is powered by OpenAI's GPT-3.5-turbo and provides intelligent responses to travel-related queries.

**Access the chatbot:** `http://localhost:3000/chatbot.html`

## 🚀 Quick Start

### Automated Setup (Easiest)

**Windows:**
```cmd
setup.bat
```

**Mac/Linux:**
```bash
chmod +x setup.sh
./setup.sh
```

### Manual Setup

1. Install dependencies
```cmd
npm install
```

2. Set OpenAI API key
```cmd
set OPENAI_API_KEY=your_api_key_here
```

3. Run the server
```cmd
npm start
```

4. Open in browser
```
http://localhost:3000
```

## 📱 Available Endpoints

### Authentication
- `POST /api/auth/register` — body: `{ name, email, password }`
- `POST /api/auth/login` — body: `{ email, password }`

### Data APIs
- `GET /api/hotels` — list of hotels
- `GET /api/destinations` — list of destinations
- `GET /api/me` — get current user (protected)

### ChatGPT Integration ✨
- `POST /api/chat` — body: `{ message }` (returns `{ reply }`)

## 🤖 ChatGPT Chatbot Features

✅ Real AI-powered responses  
✅ WhatsApp-style modern UI  
✅ Travel-focused system prompt  
✅ Mobile responsive  
✅ Quick reply suggestions  
✅ Typing indicators  
✅ Error handling  
✅ Production-ready  

## 🔑 Prerequisites

- **Node.js** (v14+) - https://nodejs.org
- **OpenAI API Key** - https://platform.openai.com/api-keys

## 📚 Documentation

- **[START_HERE.md](START_HERE.md)** - Quick start guide
- **[QUICKSTART.md](QUICKSTART.md)** - 3-minute setup
- **[CHATGPT_SETUP.md](CHATGPT_SETUP.md)** - Complete setup guide
- **[API_DOCUMENTATION.md](API_DOCUMENTATION.md)** - API reference
- **[VISUAL_OVERVIEW.md](VISUAL_OVERVIEW.md)** - Architecture & diagrams
- **[INTEGRATION_SUMMARY.md](INTEGRATION_SUMMARY.md)** - Full summary

## 💻 Development Helpers

```cmd
npm run dev      — runs nodemon server.js
npm run preview  — temporary static server on port 3000
npm start        — runs production server
```

## 🔐 Security Notes

- JWT secret is set by `JWT_SECRET` env var (change in production)
- OpenAI API key must be set via `OPENAI_API_KEY` env var
- Database file is `data/db.sqlite` (auto-created on first run)
- Never commit API keys to version control

## 📁 Project Structure

```
travelogic/
├── index.html              — main landing page
├── chatbot.html            — ChatGPT chatbot (NEW)
├── signin.html
├── signup.html
├── server.js               — Express backend
├── package.json
├── assets/                 — CSS, JS, images
├── data/                   — SQLite database
└── documentation/          — Guides & references
```

## 🎯 Testing the Chatbot

Try these prompts:
- "Plan a 5-day trip to Thailand"
- "Best budget hotels in Sylhet"
- "How much should I budget for a trip?"
- "Local attractions in Sylhet"

## 💰 ChatGPT Costs

- New accounts: $5 free credits
- Cost per message: ~$0.0002 (very affordable)
- Monitor usage: https://platform.openai.com/account/usage

## 🛠️ Customization

Edit `server.js` to customize the chatbot:
- System prompt (line ~157)
- Response length (line ~166)
- Temperature/creativity (line ~168)
- AI model (line ~164)

## 📝 Files Recently Added

✨ New ChatGPT Integration:
- `chatbot.html` - ChatGPT chatbot UI
- `setup.bat` - Windows automated setup
- `setup.sh` - Mac/Linux automated setup
- `START_HERE.md` - Quick reference
- `QUICKSTART.md` - 3-minute setup
- `CHATGPT_SETUP.md` - Complete guide
- `API_DOCUMENTATION.md` - API docs
- `INTEGRATION_SUMMARY.md` - Full summary
- `VISUAL_OVERVIEW.md` - Architecture
- `.env.example` - Environment template

## ✅ Status

🟢 ChatGPT Integration: Complete  
🟢 Documentation: Complete  
🟢 Testing: Ready  
🟢 Production: Ready to deploy
